import React from "react";

function Header() {
  return (
    <div className="header">
      <h1>รางวัลล็อตเตอรี่ Diversition</h1>
    </div>
  );
}

export default Header;
